// fill in your db credentials
exports.config = {
  host: "mysql.engr.scu.edu",
  user: "",
  password: "",
  database: "sdb_"
};